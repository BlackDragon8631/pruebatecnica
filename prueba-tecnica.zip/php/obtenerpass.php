<?php

	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');

	session_start();
	
	

	$response = array();

	include("conexion.php");

	

	//$username = $_POST['username'];//mysqli_real_escape_string($con, $_POST['username']);
	//$password = md5($_POST['password']);//mysqli_real_escape_string($con, $_POST['password']);

	$query = "SELECT * FROM usuarios";
	$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
	$i=0;
	while ($columna = mysqli_fetch_array( $resultado )){
		$response[$i]['status'] = 'loggedin';
		$response[$i]['user'] = $columna[4];
		$response[$i]['id'] =$columna[0];
		$response[$i]['Nombre'] = $columna[1];
		$response[$i]['Pais'] = $columna[2];
		$response[$i]['Tipo'] = $columna[3];
		$response[$i]['Secret'] = $columna[5];
		$_SESSION[$i]['id'] = $columna[0];
		$_SESSION[$i]['user'] = $columna[4];
		$i++;
	};
	echo json_encode($response); 
	mysqli_close( $conexion );


?>