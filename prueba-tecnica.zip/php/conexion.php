<?php $usuario = "db_hoteles";
$password = "hoteles-71295";
$servidor = "localhost";
$basededatos = "db_hoteles";

$conexion = mysqli_connect( $servidor, $usuario, $password) or die ("No se ha podido conectar al servidor de Base de datos");
$db = mysqli_select_db( $conexion, $basededatos ) or die ( "Upps! No se puede acceder a la base de datos" );
?>