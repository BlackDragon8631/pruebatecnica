<?php

	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');

	session_start();
	
	

	$response = array();

	include("conexion.php");

	$tildes = $conexion->query("SET NAMES 'utf8'");
	$query = "SELECT * FROM habitaciones";

	$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
	$i=0;
	while ($columna = mysqli_fetch_array( $resultado )){

		$response[$i]['id'] = $columna[0];
		$response[$i]['hotelId'] = $columna[1];
		$response[$i]['Numcuarto'] = $columna[2];
		$response[$i]['piso'] = $columna[3];
		$response[$i]['numeroCamas'] = $columna[4];
		$response[$i]['descripcion'] = $columna[5];
		$response[$i]['tipoHabitacion'] = $columna[6];
		$response[$i]['valorBase'] = $columna[7];
		$response[$i]['porcentajeImpuesto'] = $columna[8];
		$response[$i]['cantPersonas'] = $columna[9];
		$response[$i]['habilitado'] = $columna[10];

		$i++;
	};
	echo json_encode($response); 
	mysqli_close( $conexion );


?>