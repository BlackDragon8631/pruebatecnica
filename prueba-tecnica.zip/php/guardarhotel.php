<?php
	
	$postdata = file_get_contents("php://input");
	
	$request = json_decode($postdata);
	$nombre = $request->nombre;
	$pais = $request->pais;
	$ciudad = $request->ciudad;
	$direccion = $request->direccion;
	$habilitado = $request->habilitado;
	$idvendedor = $request->idVendedor;

	include("conexion.php");

	$tildes = $conexion->query("SET NAMES 'utf8'");
	$query = "INSERT INTO hotel (Nombre, Pais, Ciudad, Direccion, habilitado, idVendedor) VALUES ('$nombre', '$pais', '$ciudad', '$direccion', $habilitado, $idvendedor)";
	$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
	echo "Dato almacenado";
	
	mysqli_close( $conexion );


?>