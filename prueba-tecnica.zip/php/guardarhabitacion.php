<?php
	
	$postdata = file_get_contents("php://input");
	
	$request = json_decode($postdata);

	$hotelId = $request->hotelId;
	$Numcuarto = $request->Numcuarto;
	$piso = $request->piso;
	$tipoHabitacion = $request->tipoHabitacion;
	$numeroCamas = $request->numeroCamas;
	$valorBase = $request->valorBase;
	$porcentajeImpuesto = $request->porcentajeImpuesto;
	$cantPersonas = $request->cantPersonas;
	$descripcion = $request->descripcion;
	$habilitado = $request->habilitado;

	include("conexion.php");

	$tildes = $conexion->query("SET NAMES 'utf8'");
	$query = "INSERT INTO habitaciones (HotelId, Numcuarto, piso, numeroCamas, descripcion, Tipo, ValorBase, Impuestos, CantidadPersonas, habilitada) VALUES ($hotelId, $Numcuarto, '$piso', $numeroCamas, '$descripcion', $tipoHabitacion, $valorBase, $porcentajeImpuesto, $cantPersonas, $habilitado)";
	$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
	echo "Dato almacenado";
	
	mysqli_close( $conexion );


?>