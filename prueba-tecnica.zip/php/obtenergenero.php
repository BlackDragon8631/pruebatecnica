<?php

	header('Access-Control-Allow-Origin: *');
	header('Content-Type: application/json');

	session_start();
	
	

	$response = array();

	include("conexion.php");

	$tildes = $conexion->query("SET NAMES 'utf8'");
	$query = "SELECT * FROM genero";

	$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
	$i=0;
	while ($columna = mysqli_fetch_array( $resultado )){

		$response[$i]['id'] = $columna[0];
		$response[$i]['genero'] = $columna[1];
		$i++;
	};
	echo json_encode($response); 
	mysqli_close( $conexion );


?>