<?php
	
	$postdata = file_get_contents("php://input");
	
	$request = json_decode($postdata);
	$fechallegada = $request->fechallegada;
	$fechasalida = $request->fechasalida;
	$idHotel = $request->idHotel;
	$idHabitacion = $request->idHabitacion;
	$idUsuario = $request->idUsuario;
	$nombreCE = $request->nombreCE;
	$telefonoCE = $request->telefonoCE;

	include("conexion.php");

	$tildes = $conexion->query("SET NAMES 'utf8'");
	$query = "INSERT INTO reservas (fechallegada, fechasalida, idHotel, idHabitacion, idUsuario, nombreCE, telefonoCE) VALUES ('$fechallegada', '$fechasalida', $idHotel, $idHabitacion, $idUsuario, '$nombreCE', '$telefonoCE')";

	
	$resultado = mysqli_query( $conexion, $query ) or die ( "Algo ha ido mal en la consulta a la base de datos");
	echo "Dato almacenado";

	mysqli_close( $conexion );


?>