
app.controller("LogInController", ["$scope", "$window", "$http", "$location", "User", function($scope,$window,$http,$location,User){
	
	$scope.usuarioconectado=User.getAll();
	if($scope.usuarioconectado.status=== "loggedin"){
		$scope.usuarioestaOn = true;
	} else {
		$scope.usuarioestaOn = false;
	};
	$scope.tipoUsuario = User.getTipo();

	
	$scope.login = function(){
		
		$http.get("php/obtenerpass.php")
		.then(function(data,status,headers,config){
			$scope.newLogIn = data.data;
			for(var i=0; i<data.data.length; i++) {
				if((data.data[i].Secret===$scope.password)&&(data.data[i].user===$scope.username)){
					User.add(data.data[i]);
				}
			}
			$window.location.reload();
		}, function(error,status,headers,config){
			console.log(error);

		});
	};
	$scope.logout = function() {
		User.clean();
		$window.location.reload();
	};
}]);

app.controller("IndexController", ["$scope", function($scope){
	
}]);

app.controller("HotelController", ["$scope", "$http", "User", function($scope, $http, User){
	$scope.hdatos = {};
	$scope.hdatos.idVendedor = User.getId();
	$scope.hotelGuardado = false;

	$scope.enviar = function() {
		console.log($scope.hdatos);
		var cadenaDatos = 
			'{"idVendedor": "'+$scope.hdatos.idVendedor+
			'", "nombre": "'+$scope.hdatos.nombre+
			'", "pais": "'+$scope.hdatos.pais+
			'", "habilitado": "'+$scope.hdatos.habilitado+
			'", "ciudad": "'+$scope.hdatos.ciudad+
			'", "direccion": "'+$scope.hdatos.direccion+'"}';
		$http.post("php/guardarhotel.php", cadenaDatos)
		.then(function(data,status,headers,config){
			console.log(data);
			if(data.data == "Dato almacenado")  {
				$scope.hdatos = [];
				$scope.hotelGuardado = true;
			} else {
				$scope.hotelGuardado = false;
			}
		}, function(error,status,headers,config){
			console.log(error);
        });  
	}

}]);

app.controller("HabitController", ["$scope", "$http", "User", function($scope, $http, User){
	$scope.listaHoteles=[];
	$scope.habdatos ={};
	var idVendedor = User.getId();
	$http.get("php/obtenerhoteles.php")
	.then(function(data,status,headers,config){
		for(var i=0; i<data.data.length; i++){
			if(data.data[i].idVendedor == idVendedor){
				$scope.listaHoteles.push(data.data[i]);
			}
		}
	}, function(error,status,headers,config){
		console.log(error);
	});
	$http.get("php/obtenertipohab.php")
	.then(function(data,status,headers,config){
		$scope.tipoHabitaciones = data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});

	$scope.enviar = function() {
		console.log($scope.habdatos);
		var cadenaDatos = 
			'{"hotelId": "'+$scope.habdatos.hotelId+
			'", "Numcuarto": "'+$scope.habdatos.Numcuarto+
			'", "piso": "'+$scope.habdatos.piso+
			'", "tipoHabitacion": "'+$scope.habdatos.tipoHabitacion+
			'", "numeroCamas": "'+$scope.habdatos.numeroCamas+
			'", "valorBase": "'+$scope.habdatos.valorBase+
			'", "porcentajeImpuesto": "'+$scope.habdatos.porcentajeImpuesto+
			'", "cantPersonas": "'+$scope.habdatos.cantPersonas+
			'", "descripcion": "'+$scope.habdatos.descripcion+
			'", "habilitado": "'+$scope.habdatos.habilitado+'"}';
		
		$http.post("php/guardarhabitacion.php", cadenaDatos)
		.then(function(data,status,headers,config){
			
			if(data.data == "Dato almacenado")  {
				$scope.habdatos = [];
				$scope.hotelGuardado = true;
			} else {
				$scope.hotelGuardado = false;
			}
		}, function(error,status,headers,config){
			console.log(error);
        });  
	}
	
}]);

app.controller("HotelEditarController", ["$scope", "$http", "User", function($scope, $http, User){
	$scope.listaHoteles=[];
	$scope.habdatos ={};
	var idVendedor = User.getId();
	var habitaciones = {};
	var habHotel = {};
	$http.get("php/obtenerhabitaciones.php")
	.then(function(data,status,headers,config){
		habitaciones=data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenerhoteles.php")
	.then(function(data,status,headers,config){
		for(var i=0; i<data.data.length; i++){
			if(data.data[i].idVendedor == idVendedor){
				for(var j=0; j<habitaciones.length; j++) {
					if(habitaciones[j].hotelId == data.data[i].id) {
						habHotel.push(habitaciones[j]);
					}
				}
				data.data[i].habitaciones = habHotel;
				habHotel = [];
				$scope.listaHoteles.push(data.data[i]);

				console.log($scope.listaHoteles);
			}
		}
	}, function(error,status,headers,config){
		console.log(error);
	});
}]);

app.controller("HotelEditar", ["$scope", "$http", "$routeParams", function($scope, $http,$routeParams){
	$scope.hotelInfo ={};
	$scope.hdatos=$scope.hotelInfo;
	$http.get("php/obtenerhoteles.php")
		.then(function(data,status,headers,config){
			for(var i=0; i<data.data.length; i++){
				if(data.data[i].id == $routeParams.name){
					$scope.hotelInfo = data.data[i];
					$scope.hoteldatos = data.data[i];
					
				}
			}
		},
		function(error,status,headers,config){
			console.log(error);
		});
		console.log($scope.hotelInfo);
	$scope.enviar = function() {
		console.log($scope.hoteldatos);
		var cadenaDatos = 
			'{"id": "'+$scope.hoteldatos.id+
			'", "idVendedor": "'+$scope.hoteldatos.idVendedor+
			'", "nombre": "'+$scope.hoteldatos.Nombre+
			'", "pais": "'+$scope.hoteldatos.Pais+
			'", "habilitado": "'+$scope.hoteldatos.Habilitado+
			'", "ciudad": "'+$scope.hoteldatos.Ciudad+
			'", "direccion": "'+$scope.hoteldatos.Direccion+'"}';
		console.log(cadenaDatos);
		$http.post("php/updatehotel.php", cadenaDatos)
		.then(function(data,status,headers,config){
			console.log(data);
			if(data.data == "Dato almacenado")  {
				$scope.hotelGuardado = true;
			} else {
				$scope.hotelGuardado = false;
			}
		}, function(error,status,headers,config){
			console.log(error);
        });  
	}
	
}]);

app.controller("HabitacionEditar", ["$scope", "$http", "$routeParams", function($scope, $http,$routeParams){
	$scope.habitacionInfo ={};
	$scope.hdatos=$scope.habitacionInfo;
	$scope.hotelName ="";
	
	$http.get("php/obtenertipohab.php")
	.then(function(data,status,headers,config){
		$scope.tipoHabitaciones = data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenerhabitaciones.php")
		.then(function(data,status,headers,config){
			for(var i=0; i<data.data.length; i++){
				if(data.data[i].id == $routeParams.habi){
					$scope.habitacionInfo = data.data[i];
					$scope.hdatos = data.data[i];

				}
			}
		},
		function(error,status,headers,config){
			console.log(error);
		});
		
	$http.get("php/obtenerhoteles.php")
		.then(function(data,status,headers,config){
			for(var j=0; j<data.data.length; j++){
				if(data.data[j].id == $routeParams.name){
					$scope.hotelName = data.data[j].Nombre;
				}
			}
		},
		function(error,status,headers,config){
			console.log(error);
		});

	$scope.enviar = function() {
		var cadenaDatos = 
			'{"id": "'+$scope.hdatos.id+
			'", "hotelId": "'+$scope.hdatos.hotelId+
			'", "Numcuarto": "'+$scope.hdatos.Numcuarto+
			'", "piso": "'+$scope.hdatos.piso+
			'", "tipoHabitacion": "'+$scope.hdatos.tipoHabitacion+
			'", "numeroCamas": "'+$scope.hdatos.numeroCamas+
			'", "valorBase": "'+$scope.hdatos.valorBase+
			'", "porcentajeImpuesto": "'+$scope.hdatos.porcentajeImpuesto+
			'", "cantPersonas": "'+$scope.hdatos.cantPersonas+
			'", "descripcion": "'+$scope.hdatos.descripcion+
			'", "habilitado": "'+$scope.hdatos.habilitado+'"}';
		console.log(cadenaDatos);
		$http.post("php/updatehabitacion.php", cadenaDatos)
		.then(function(data,status,headers,config){
			console.log(data);
			if(data.data == "Dato almacenado")  {
				$scope.hotelGuardado = true;
			} else {
				$scope.hotelGuardado = false;
			}
		}, function(error,status,headers,config){
			console.log(error);
        });  
	}
}]);

app.controller("ReservasController", ["$scope", function($scope){

}]);

app.controller("BuscarController", ["$scope", "$http","$routeParams", function($scope,$http,$routeParams){
	
	$scope.listaHoteles=[];
	$scope.habdatos ={};
	var habitaciones = {};
	var habHotel = {};
	var tipHabita = {};

	$http.get("php/obtenertipohab.php")
	.then(function(data,status,headers,config){
		tipHabita = data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenerhabitaciones.php")
	.then(function(data,status,headers,config){
		habitaciones=data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenerhoteles.php")
	.then(function(data,status,headers,config){
		for(var i=0; i<data.data.length; i++){
			for(var j=0; j<habitaciones.length; j++) {
				if((habitaciones[j].hotelId == data.data[i].id)) {
					for(var k=0; k<tipHabita.length;k++){
						if(habitaciones[j].tipoHabitacion == tipHabita[k].id){
							habitaciones[j].nomTipo = tipHabita[k].Tipo;
							
						}
					}
					habHotel.push(habitaciones[j]);
				}
			}
			data.data[i].habitaciones = habHotel;
			
			habHotel = [];
			$scope.listaHoteles.push(data.data[i]);
			
		}
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenerciudades.php")
		.then(function(data,status,headers,config){
			$scope.ciudades = data.data;
		}, function(error,status,headers,config){
			console.log(error);
		});

	
	document.querySelector("#numPersonas").addEventListener("change",function(){
		$scope.$apply(function(){
			$scope.rdatos.numPersonas = parseFloat(document.querySelector("#numPersonas").value);
			
		})
	});
}]);


app.controller("ReservarController", ["$scope", "$http", "$routeParams","User", "$location", "$filter",  function($scope, $http,$routeParams,User, $location, $filter){
	
	$scope.listaHoteles={};
	$scope.habdatos ={};
	$scope.resModel = {};
	var habitaciones = {};
	var habHotel = {};
	var tipHabita = {};
	var idUsuario = User.getId();
	var idReserva = {};
	$http.get("php/obtenertipohab.php")
	.then(function(data,status,headers,config){
		tipHabita = data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenerhabitaciones.php")
	.then(function(data,status,headers,config){
		for(var i=0; i<data.data.length; i++){
			if(data.data[i].id == $routeParams.habi) {
				habitaciones=data.data[i];
			}
		}
		for(var k=0; k<tipHabita.length;k++){
			if(habitaciones.tipoHabitacion == tipHabita[k].id){
				habitaciones.nomTipo = tipHabita[k].Tipo;
			}
		}
		console.log(habitaciones);
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenerhoteles.php")
	.then(function(data,status,headers,config){
		for(var i=0; i<data.data.length; i++){
			if(habitaciones.hotelId == data.data[i].id) {
				habHotel =habitaciones;
			}
			
			
			data.data[i].habitaciones = habHotel;
			
			habHotel = [];
			if(data.data[i].id == $routeParams.name){
				$scope.listaHoteles =data.data[i];
			}
			
		}
		console.log($scope.listaHoteles);
	}, function(error,status,headers,config){
		console.log(error);
	});
	

	$http.get("php/obtenergenero.php")
	.then(function(data,status,headers,config){
		$scope.genero = data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});

	$http.get("php/obtenertipdocumento.php")
	.then(function(data,status,headers,config){
		$scope.tipdocumento = data.data;
	}, function(error,status,headers,config){
		console.log(error);
	});
	$scope.enviar = function() {
		var cadenaDatos = 
			'{"fechallegada": "'+$filter('date')($scope.resModel.fechaLlegada, 'yyyy-MM-dd')+
			'", "fechasalida": "'+$filter('date')($scope.resModel.fechaSalida, 'yyyy-MM-dd')+
			'", "idHotel": "'+$routeParams.name+
			'", "idHabitacion": "'+$routeParams.habi+
			'", "idUsuario": "'+idUsuario+
			'", "nombreCE": "'+$scope.resModel.nombreCE+
			'", "telefonoCE": "'+$scope.resModel.telefonoCE+'"}';
		console.log(cadenaDatos);
		$http.post("php/guardarreserva.php", cadenaDatos)
		.then(function(data,status,headers,config){
			console.log(data);
			$http.get("php/ultimareserva.php")
				.then(function(data,status,headers,config){
					idReserva = data.data;

					$location.path('/reserva/huespedes/'+idReserva+'/'+$scope.resModel.numPersonas);
				}, function(error,status,headers,config){
					console.log(error);
		        }); 
		}, function(error,status,headers,config){
			console.log(error);
        });  
	}
}]);

app.controller("ReservarController2", ["$scope", "$http", "$routeParams","User", "$location", "$filter",  function($scope, $http,$routeParams,User, $location, $filter){
	var idReserva = $routeParams.name;
	var cantPersonas = $routeParams.cantper;
	var hus = [];
	var array={};
	$scope.rdata = {};
	for (var i=0; i<cantPersonas; i++)  {
		hus.nombre=i;
		hus.nace=i;
		hus.genero=i;
		hus.tipdoc=i;
		hus.numdoc=i;
		hus.email=i;
		hus.telefono=i;
		console.log(hus);
		array.push(hus);
	};
	//$scope.rdata = hus;
	console.log($scope.rdata);

}]);