var app = angular.module("PruebaTecnica",["LocalStorageModule", "ngRoute"]);
app.factory("User",function(localStorageService){
	var user = {};
	user.key = "loginusr";

	if(localStorageService.get(user.key)) { //verifica si el storage existe
		user.useroggedIn = localStorageService.get(user.key); //si existe lo trae completo
	} else {
		user.useroggedIn = [{
			'status':'unknown',
			'user':'0',
			'id':'0', 
			'Nombre':'0',
			'Pais':'0',
			'Tipo':'0',
			'Secret':'', 
			'id':'0', 
			'user':'0'}];// si no crea uno nuevo
	}


	user.add = function(newActv) {
		user.useroggedIn = [];
		user.useroggedIn.push(newActv);
		user.updaLocalStorage(); 
	};
	
	user.updaLocalStorage = function () {
		localStorageService.set(user.key,user.useroggedIn);  //Agrega lo ingresado al localStorage
	};

	user.clean = function() {
		user.useroggedIn = [{
			'status':'unknown',
			'user':'0',
			'id':'0', 
			'Nombre':'0',
			'Pais':'0',
			'Tipo':'0',
			'Secret':'', 
			'id':'0', 
			'user':'0'}];
		user.updaLocalStorage();
	};

	user.getAll = function() {
		return user.useroggedIn[0];
	};

	user.getTipo = function() {
		return user.useroggedIn[0].Tipo;
	};


	user.getId = function() {
		return user.useroggedIn[0].id;
	};

	user.islogged = function() {
		if(user.useroggedIn[0].status === "loggedin"){
			return true;
		} else {
			return false;
		}
	}
	return user;

});
app.config(function($routeProvider){
	$routeProvider
		.when("/",{
			controller: "IndexController",
			templateUrl: "views/home.html"
		})
		.when("/login",{
			controller: "LogInController",
			templateUrl: "views/login.html"
		})
		.when("/crear-hotel",{
			controller: "HotelController",
			templateUrl: "views/crear-hotel.html"
		})
		.when("/asignar-habitaciones",{
			controller: "HabitController",
			templateUrl: "views/asignar-habitaciones.html"
		})
		.when("/editar-hotel",{
			controller: "HotelEditarController",
			templateUrl: "views/editar-hotel.html"
		})
		.when("/ver-reservas",{
			controller: "ReservasController",
			templateUrl: "views/reservas.html"
		})
		.when("/hotel/:name", {
			controller: "HotelEditar",
			templateUrl: "views/hotel-info.html"
		})
		.when("/habitacion/:name/:habi", {
			controller: "HabitacionEditar",
			templateUrl: "views/habitacion-info.html"
		})
		.when("/buscar-hotel",{
			controller: "BuscarController",
			templateUrl: "views/buscar.html"
		})
		.when("/reserva/:name/:habi", {
			controller: "ReservarController",
			templateUrl: "views/reservar.html"
		})
		.when("/reserva/huespedes/:name/:cantper", {
			controller: "ReservarController2",
			templateUrl: "views/huespedes.html"
		})
		.otherwise("/");
});
app.directive('stringToNumber', function() {
  return {
    require: 'ngModel',
    link: function(scope, element, attrs, ngModel) {
      ngModel.$parsers.push(function(value) {
        return '' + value;
      });
      ngModel.$formatters.push(function(value) {
        return parseFloat(value);
      });
    }
  };
});